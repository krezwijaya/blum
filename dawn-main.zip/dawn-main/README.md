# dawn
Dawn Internet Extension
Keep Alive Connection
edit data.txt

python dawn.py
or
python3 dawn.py

use my refferal code: doavda

extension: https://chromewebstore.google.com/detail/dawn-validator-chrome-ext/fpdkjdnhkakefebpekbdhillbhonfjjp?hl=en

how to get token ?
Developer Tools (f12) - Network - cari getpoint - ada dibagian Authorization
